package es.curso.androidlistacompleja.apps;

import java.util.ArrayList;

import android.app.ListActivity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class ListaCompleja extends ListActivity {
    /** Called when the activity is first created. */
    
	private MyAdapter mAdapter = null;
	
	//definimos una estructura de datos
	public class Node
	{
		public String mTitle;
		public String mDescription;
		public Integer mImageResource;
		
	}
	
	//Definimos un array de tipo Node
	private static ArrayList<Node> mArray = new ArrayList<Node>();
	
	
	@Override
    public void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);
        
        setData();
        
        mAdapter = new MyAdapter (this);
        setListAdapter (mAdapter);
    }
	
	protected void onListItemClick(ListView l, View v, int position, long id)
	{
		//Crea un nuevo intent para llamar a otra actividad
		Toast.makeText(this, mArray.get(position).mTitle, Toast.LENGTH_LONG).show();
	}
	
	private void setData() 
	{
		// TODO Auto-generated method stub
		
	
		mArray.clear();
		
		//Curso Tk045, 1 en la lista
		Node mynode1 = new Node();
				
		mynode1.mTitle = this.getResources().getString(R.string.title1);
		mynode1.mDescription = this.getResources().getString(R.string.description1);
		mynode1.mImageResource = R.drawable.r1_acero;
		
		mArray.add(mynode1);
		
		//Curso Tk043, 2 en la lista
		Node mynode2 = new Node();
						
		mynode2.mTitle = this.getResources().getString(R.string.title2);
		mynode2.mDescription = this.getResources().getString(R.string.description2);
		mynode2.mImageResource = R.drawable.r2_estampacion;
				
		mArray.add(mynode2);
		
		//Curso Tk041, 3 en la lista
		Node mynode3 = new Node();
						
		mynode3.mTitle = this.getResources().getString(R.string.title3);
		mynode3.mDescription = this.getResources().getString(R.string.description3);
		mynode3.mImageResource = R.drawable.r3_fresadora;
				
		mArray.add(mynode3);
				
				
	}
	
	public static class MyAdapter extends BaseAdapter
	{

		private Context mContext;
		
		public MyAdapter(Context c)
		{
			mContext = c;
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return mArray.size();
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return mArray.get(position);
		}

		@Override
		public long getItemId(int arg0) {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			
			View view = null;
			
			if (convertView == null){
				//Crea una nueva vista
				LayoutInflater inflater = (LayoutInflater) mContext
						.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				
				view = inflater.inflate(R.layout.main, null);
			}
			else{
				//usa convertView si est� disponible
				view = convertView;
			}
			
			//Rellenamos los recursos de la vista: una imagen y dos textos
			ImageView img = (ImageView) view.findViewById(R.id.image);
			img.setImageDrawable(mContext.getResources().getDrawable(mArray.get(position).mImageResource));
			
			TextView tTitle = (TextView) view.findViewById(R.id.title);
			tTitle.setText(mArray.get(position).mTitle);
			
			TextView tDescription = (TextView) view.findViewById(R.id.description);
			tDescription.setText(mArray.get(position).mDescription);
			
			
			return view;
			
		}
		
	}	
	
}